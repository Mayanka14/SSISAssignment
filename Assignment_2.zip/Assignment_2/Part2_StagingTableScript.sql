CREATE DATABASE StagingTableDatabase;
USE StagingTableDatabase;
GO

CREATE TABLE Staging_HumanResources_Employee(
	[BusinessEntityID] [varchar](50) NOT NULL,
	[NationalIDNumber] [varchar](50),
	[LoginID] [varchar](50),
	[OrganizationNode] [varchar](50),
	[OrganizationLevel][varchar](50),
	[JobTitle][varchar](50) NOT NULL,
	[BirthDate][varchar](50),
	[MaritalStatus][varchar](50),
	[Gender][varchar](50),
	[HireDate] [varchar](50),
	[SalariedFlag][varchar](50),
	[VacationHours] [varchar](50),
	[SickLeaveHours][varchar](50),
	[CurrentFlag] [varchar](50),
	[rowguid][varchar](50),
	[ModifiedDate] [varchar](50),
 CONSTRAINT [PK_Employee_BusinessEntityID] PRIMARY KEY CLUSTERED 
(
	[BusinessEntityID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SELECT * FROM Staging_HumanResources_Employee
ORDER BY BusinessEntityID;